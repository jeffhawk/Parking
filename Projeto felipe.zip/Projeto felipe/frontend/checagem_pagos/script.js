function inicia(){
    //lerTabela();
    atualizaTabelaPagoNaoSaiu();
}
window.addEventListener("load", inicia);