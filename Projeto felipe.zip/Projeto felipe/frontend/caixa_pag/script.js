function inicia(){
    atualizaTabelaNaoPago();
    atualizaTabelaPago();
}
window.addEventListener("load", inicia);