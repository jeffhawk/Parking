function inicia(){
    atualizaTabelaNaoPago();
    atualizaTabelaPago();
}
window.addEventListener("load", inicia);
document.write("" + dayName[now.getDay() ] + ", " + now.getDate () + " de " + monName [now.getMonth() ]   +  " de "  +     now.getFullYear () + ". </h1>");
