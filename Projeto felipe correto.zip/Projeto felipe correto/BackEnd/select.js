var oracledb = require('oracledb');
var dbConfig = require('./dbconfig.js');
oracledb.getConnection(
{
user : dbConfig.user,
password : dbConfig.password,
connectString : dbConfig.connectString
},
function(err, connection)
{
if (err) {
console.error(err.message);
return;
}
connection.execute(
"SELECT SYSDATE FROM DUAL",function(err, result)
{
if (err) {
console.error(err.message);
doRelease(connection);
return;
}
console.log(result.metaData); // [ { name: ‘SYSDATE’ } ]
console.log(result.rows); // [ [ 2017-12-08T19:03:45.000Z ] ]
doRelease(connection);
});
});function doRelease(connection) {
connection.close(
function(err) {
if (err) {
console.error(err.message);
}
});
}